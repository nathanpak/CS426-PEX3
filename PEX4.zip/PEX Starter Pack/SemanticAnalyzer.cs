﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using CS426.node;

namespace CS426.analysis
{
    class SemanticAnalyzer : DepthFirstAdapter
    {
        // Global symbol table
        Dictionary<string, Definition> globalSymbolTable = new Dictionary<string, Definition>();

        // local symbol table
        Dictionary<string, Definition> localSymbolTable = new Dictionary<string, Definition>();

        // this is our decorated parse tree
        Dictionary<Node, Definition> decoratedParseTree = new Dictionary<Node, Definition>();

        // current function name
        string currFuncName = "";

        // current function call name
        string currCalledFuncName = "";

        // current function call arguments
        List<TypeDefinition> args;

        public void PrintWarning(Token t, String message)
        {
            Console.WriteLine("Line " + t.Line + ", Col " + t.Pos + ": " + message);
        }

        public override void InAConstsandfuncsProgram(AConstsandfuncsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAFuncsProgram(AFuncsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAConstsProgram(AConstsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAOnlymainProgram(AOnlymainProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        /**
         * OPERANDS
         */
        public override void OutAIntOperand(AIntOperand node)
        {
            // create the definition
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            decoratedParseTree.Add(node, intDefinition);
        }

        public override void OutAVariableOperand(AVariableOperand node)
        {
            // get name of id
            String varName = node.GetId().Text;

            Definition varDefinition;

            // see if varName is in local symbol table
            if (!localSymbolTable.TryGetValue(varName, out varDefinition) && !globalSymbolTable.TryGetValue(varName, out varDefinition))
            {
                PrintWarning(node.GetId(), varName + " does not exist.");
            }
            // see if varDefinition is actually a variable
            else if(!(varDefinition is VariableDefinition))
            {
                PrintWarning(node.GetId(), varName + " is not a variable");
            }
            else
            {
                VariableDefinition v = (VariableDefinition)varDefinition;

                // decorating node with type of the variable
                decoratedParseTree.Add(node, v.variableType);
            }
        }

        public override void OutAFloatOperand(AFloatOperand node)
        {
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            decoratedParseTree.Add(node, floatDefinition);
        }

        public override void OutAStringOperand(AStringOperand node)
        {
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            decoratedParseTree.Add(node, strDefinition);
        }

        /**
         * Expression 10
         */
        public override void OutAPassExpression10(APassExpression10 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetOperand(), out operandDefinition)) 
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutANegativeExpression10(ANegativeExpression10 node)
        {
            Definition operandDefinition;

            if (!decoratedParseTree.TryGetValue(node.GetOperand(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else if(!(operandDefinition is NumberDefinition))
            {
                PrintWarning(node.GetSub(), "Only a number can be negated.");
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutANotExpression10(ANotExpression10 node)
        {
            Definition operandDefinition;

            if (!decoratedParseTree.TryGetValue(node.GetExpression9(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else if (!(operandDefinition is BooleanDefinition))
            {
                PrintWarning(node.GetNot(), "Not can only be applied to boolean expressions.");
            }
            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = operandDefinition.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * Expression 9
         */
        public override void OutAPassExpression9(APassExpression9 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression10(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAParenthesesExpression9(AParenthesesExpression9 node)
        {
            Definition expressionType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionType))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, expressionType);
            }
        }

        /**
         * Expression 8
         */
        public override void OutAPassExpression8(APassExpression8 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression9(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

       public override void OutAIncrementExpression8(AIncrementExpression8 node)
        {
            Definition expression8Def;
            if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out expression8Def)) { 
                // there was an error but we don't have to print it
            }
            /*else if(!(expression8Def is VariableDefinition))
            {
                PrintWarning(node.GetIncrement(), "Only variables may be incremented");
            }*/
            else if(!(expression8Def is FloatDefinition) && !(expression8Def is NumberDefinition))
            {
                PrintWarning(node.GetIncrement(), "Only variable type float and int may be incremented");
            }
            else
            {
                decoratedParseTree.Add(node, expression8Def);
            }
        }

        public override void OutADecrementExpression8(ADecrementExpression8 node)
        {
            Definition expression8Def;
            if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out expression8Def))
            {
                // there was an error but we don't have to print it
            }
            /*else if(!(expression8Def is VariableDefinition))
            {
                PrintWarning(node.GetIncrement(), "Only variables may be incremented");
            }*/
            else if (!(expression8Def is FloatDefinition) && !(expression8Def is NumberDefinition))
            {
                PrintWarning(node.GetDecrement(), "Only variable type float and int may be decremented");
            }
            else
            {
                decoratedParseTree.Add(node, expression8Def);
            }
        }

        /**
         * Expression 6
         */
        public override void OutAPassExpression6(APassExpression6 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAMultiplyExpression6(AMultiplyExpression6 node)
        {
            Definition expression6Def;
            Definition expression8Def;

            if(!decoratedParseTree.TryGetValue(node.GetExpression6(), out expression6Def))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out expression8Def))
            {
                // there was error but we dont have to print it
            }
            else if(expression6Def.GetType() != expression8Def.GetType())
            {
                PrintWarning(node.GetMult(), "Cannot multiply " + expression6Def.name + " by " + expression8Def.name);
            }
            else if(!(expression6Def is NumberDefinition) && !(expression6Def is FloatDefinition))
            {
                PrintWarning(node.GetMult(), "You can only multiply ints and floats");
            }
            else
            {
                decoratedParseTree.Add(node, expression6Def);
            }
        }

        public override void OutADivisionExpression6(ADivisionExpression6 node)
        {
            Definition expression6Def;
            Definition expression8Def;

            if (!decoratedParseTree.TryGetValue(node.GetExpression6(), out expression6Def))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out expression8Def))
            {
                // there was error but we dont have to print it
            }
            else if (expression6Def.GetType() != expression8Def.GetType())
            {
                PrintWarning(node.GetDiv(), "Cannot divide " + expression6Def.name + " by " + expression8Def.name);
            }
            else if (!(expression6Def is NumberDefinition) && !(expression6Def is FloatDefinition))
            {
                PrintWarning(node.GetDiv(), "You can only divide ints and floats");
            }
            else
            {
                decoratedParseTree.Add(node, expression6Def);
            }
        }

        /**
         * Expression 4
         */
        public override void OutAPassExpression4(APassExpression4 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression6(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAAddExpression4(AAddExpression4 node)
        {
            Definition expression4Type;
            Definition expression6Type;

            if (!decoratedParseTree.TryGetValue(node.GetExpression4(), out expression4Type))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression6(), out expression6Type))
            {
                // there was error but we dont have to print it
            }
            else if (expression4Type.name != expression6Type.name)
            {
                PrintWarning(node.GetPlus(), "Cannot not add " + expression4Type.name + " and " + expression6Type.name);
            }
            else if(!(expression4Type is NumberDefinition) && !(expression4Type is FloatDefinition))
            {
                PrintWarning(node.GetPlus(), "You can only add ints and floats");
            }
            else
            {
                decoratedParseTree.Add(node, expression4Type);
            }
        }

        public override void OutASubtractExpression4(ASubtractExpression4 node)
        {
            Definition expression4Type;
            Definition expression6Type;

            if (!decoratedParseTree.TryGetValue(node.GetExpression4(), out expression4Type))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression6(), out expression6Type))
            {
                // there was error but we dont have to print it
            }
            else if (expression4Type.name != expression6Type.name)
            {
                PrintWarning(node.GetSub(), "Cannot not subtract " + expression4Type.name + " and " + expression6Type.name);
            }
            else if (!(expression4Type is NumberDefinition) && !(expression4Type is FloatDefinition))
            {
                PrintWarning(node.GetSub(), "You can only subtract ints and floats");
            }
            else
            {
                decoratedParseTree.Add(node, expression4Type);
            }
        }

        /**
         * Expression 3
         */
        public override void OutAPassExpression3(APassExpression3 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression4(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutALessExpression3(ALessExpression3 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetLess(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        public override void OutALessequalExpression3(ALessequalExpression3 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetLessequal(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        public override void OutAGreaterequalExpression3(AGreaterequalExpression3 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetGreaterequal(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        public override void OutAGreaterExpression3(AGreaterExpression3 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetGreater(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }


        /**
         * Expression 2
         */
        public override void OutAPassExpression2(APassExpression2 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression3(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAEqualExpression2(AEqualExpression2 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetEqual(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        public override void OutANotequalExpression2(ANotequalExpression2 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetLeftside(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetRightside(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (leftSideType is StringDefinition || rightSideType is StringDefinition)
            {
                PrintWarning(node.GetNotequal(), "Cannot compare string");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * Expression 1
         */
        public override void OutAPassExpression1(APassExpression1 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression2(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAAndExpression1(AAndExpression1 node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression1(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression2(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (!(leftSideType is BooleanDefinition) || !(rightSideType is BooleanDefinition))
            {
                PrintWarning(node.GetAnd(), "AND can only be applied to booleans");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * Expression
         */
        public override void OutAPassExpression(APassExpression node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression1(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutAOrExpression(AOrExpression node)
        {
            Definition leftSideType;
            Definition rightSideType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out leftSideType))
            {
                // there was an error but we dont have to print it
            }
            else if (!decoratedParseTree.TryGetValue(node.GetExpression1(), out rightSideType))
            {
                // there was error but we dont have to print it
            }
            else if (!(leftSideType is BooleanDefinition) || !(rightSideType is BooleanDefinition))
            {
                PrintWarning(node.GetOr(), "OR can only be applied to booleans");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = leftSideType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * Declare Statements
         */
        public override void OutARegularDeclareStatement(ARegularDeclareStatement node)
        {
            Definition typeDef;
            Definition idDef;

            if (!globalSymbolTable.TryGetValue(node.GetType().Text, out typeDef))
            {
                PrintWarning(node.GetType(), "Type " + node.GetType().Text + " does not exist.");
            }
            else if (!(typeDef is TypeDefinition))
            {
                PrintWarning(node.GetType(), "Identifier " + node.GetType().Text + " is not a recognized data type");
            }
            else if (localSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }
            else if (globalSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }
            else
            {
                VariableDefinition newVariableDefinition = new VariableDefinition();
                newVariableDefinition.name = node.GetVarname().Text;
                newVariableDefinition.variableType = (TypeDefinition)typeDef;

                localSymbolTable.Add(node.GetVarname().Text, newVariableDefinition);
            }
        }

        /**
         * Assignments
         */
        public override void OutANormalAssignStatement(ANormalAssignStatement node)
        {
            Definition idDef;
            Definition expressionDef;

            if(!localSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " does not exist.");
            }
            else if(!(idDef is VariableDefinition))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " is not a variable.");
            }
            else if(!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionDef))
            {
                // no need to print error message
            }
            else if (((VariableDefinition)idDef).variableType.name != expressionDef.name)
            {
                PrintWarning(node.GetId(), "Types do not match");
            }
            else
            {
                // nothing is required! valid assignment.
            }
        }

        public override void OutASingleConstant(ASingleConstant node)
        {
            Definition typeDef;
            Definition idDef;
            Definition expressionDef;

            if (!globalSymbolTable.TryGetValue(node.GetType().Text, out typeDef))
            {
                PrintWarning(node.GetType(), "Type " + node.GetType().Text + " does not exist.");
            }
            else if (!(typeDef is TypeDefinition))
            {
                PrintWarning(node.GetType(), "Identifier " + node.GetType().Text + " is not a recognized data type");
            }
            else if (globalSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }
            /*else if (globalSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }*/
            else if (!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionDef))
            {
                // no need to print error message
            }
            else if (typeDef.name != expressionDef.name)
            {
                PrintWarning(node.GetType(), "Types do not match");
            }
            else
            {
                VariableDefinition newVariableDefinition = new VariableDefinition();
                newVariableDefinition.name = node.GetVarname().Text;
                newVariableDefinition.variableType = (TypeDefinition)typeDef;

                globalSymbolTable.Add(node.GetVarname().Text, newVariableDefinition);
            }





        }

        /**
         * If Statements
         */
        public override void OutAIfIfStatement(AIfIfStatement node)
        {
            Definition conditionType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out conditionType))
            {
                // there was an error but we dont have to print it
            }
            else if (!(conditionType is BooleanDefinition))
            {
                PrintWarning(node.GetIf(), "Condition must be boolean");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = conditionType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        public override void OutAIfelseIfStatement(AIfelseIfStatement node)
        {
            Definition conditionType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out conditionType))
            {
                // there was an error but we dont have to print it
            }
            else if (!(conditionType is BooleanDefinition))
            {
                PrintWarning(node.GetIf(), "Condition must be boolean");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = conditionType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * While Loop
         */
        public override void OutAWhileWhileStatement(AWhileWhileStatement node)
        {
            Definition conditionType;
            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out conditionType))
            {
                // there was an error but we dont have to print it
            }
            else if (!(conditionType is BooleanDefinition))
            {
                PrintWarning(node.GetWhile(), "Condition must be boolean");
            }

            else
            {
                BooleanDefinition b = new BooleanDefinition();
                b.name = conditionType.name;
                decoratedParseTree.Add(node, b);
            }
        }

        /**
         * Function Definition
         */
        public override void InAParametersFunc(AParametersFunc node)
        {
            Definition idDef; 

            if(globalSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " is already being used.");
            }
            else
            {
                

                localSymbolTable = new Dictionary<string, Definition>();

                // register the new function definition in the global table
                currFuncName = node.GetId().Text;
                FunctionDefinition newFunctionDefinition = new FunctionDefinition();
                newFunctionDefinition.name = node.GetId().Text;

                newFunctionDefinition.parameters = new List<VariableDefinition>();

                globalSymbolTable.Add(node.GetId().Text, newFunctionDefinition);
            }
            
        }

        public override void InANoparametersFunc(ANoparametersFunc node)
        {
            Definition idDef;

            if (globalSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " is already being used.");
            }
            else
            {
                localSymbolTable = new Dictionary<string, Definition>();

                // register the new function definition in the global table
                FunctionDefinition newFunctionDefinition = new FunctionDefinition();
                newFunctionDefinition.name = node.GetId().Text;

                newFunctionDefinition.parameters = new List<VariableDefinition>();

                globalSymbolTable.Add(node.GetId().Text, newFunctionDefinition);
            }
        }

        public override void OutAParametersFunc(AParametersFunc node)
        {
            localSymbolTable = new Dictionary<string, Definition>();
        }

        public override void OutANoparametersFunc(ANoparametersFunc node)
        {
            localSymbolTable = new Dictionary<string, Definition>();
        }

        public override void OutASingleNewfuncparameter(ASingleNewfuncparameter node)
        {
            

            Definition typeDef;
            Definition idDef;

            if (!globalSymbolTable.TryGetValue(node.GetType().Text, out typeDef))
            {
                PrintWarning(node.GetType(), "Type " + node.GetType().Text + " does not exist.");
            }
            else if (!(typeDef is TypeDefinition))
            {
                PrintWarning(node.GetType(), "Identifier " + node.GetType().Text + " is not a recognized data type");
            }
            else if (localSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }
            /*else if (globalSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }*/
            else
            {
                VariableDefinition parameter = new VariableDefinition();
                parameter.name = node.GetVarname().Text;
                parameter.variableType = (TypeDefinition)typeDef;

                localSymbolTable.Add(node.GetVarname().Text, parameter);

                // add parameter to its function's parameter list
                Definition def;
                if (!globalSymbolTable.TryGetValue(currFuncName, out def))
                {
                    PrintWarning(node.GetType(), "Something is wrong");
                }
                else
                {
                    FunctionDefinition functionDef = new FunctionDefinition();
                    functionDef = (FunctionDefinition)def;
                    functionDef.parameters.Add(parameter);
                }
            }
        }

        /**
         * Function Calls
         */
        public override void OutAParamsFunctionCallStatement(AParamsFunctionCallStatement node)
        {
            Definition idDef;

            if(!globalSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "ID " + node.GetId().Text + " not found.");
            }
            else if(!(idDef is FunctionDefinition))
            {
                PrintWarning(node.GetId(), "ID " + node.GetId().Text + " is not a function.");
            }
            
            else
            {
                FunctionDefinition funcDef = new FunctionDefinition();
                funcDef = (FunctionDefinition)idDef;
                args.Reverse(); // for sum reason, this list was in reverse order
                int numParams = funcDef.parameters.Count;
                int numArgs = args.Count;

                if(numParams != numArgs)
                {
                    PrintWarning(node.GetOpenparen(), "Number of arguments do not match function definition");
                }
                else
                {
                    for(int i = 0; i < numParams; i++)
                    {
                        if (args[i].name != funcDef.parameters[i].variableType.name)
                        {
                            PrintWarning(node.GetOpenparen(), args[i].name + " cannot be used as a " + funcDef.parameters[i].variableType.name + " parameter");
                        }
                    }
                    // once you get here there are no problems with the function call
                }

            }
        }

        public override void InAParamsFunctionCallStatement(AParamsFunctionCallStatement node)
        {
            currCalledFuncName = node.GetId().Text;
            args = new List<TypeDefinition>();
        }

        public override void OutANoparamsFunctionCallStatement(ANoparamsFunctionCallStatement node)
        {
            Definition idDef;

            if (!globalSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "ID " + node.GetId().Text + " not found.");
            }
            else if (!(idDef is FunctionDefinition))
            {
                PrintWarning(node.GetId(), "ID " + node.GetId().Text + " is not a function.");
            }
            else
            {
                // do nothing HAHAHAHAHAHA
            }
        }

        /**
         * Function Call Parameters
         */
        public override void OutASingleParameters(ASingleParameters node)
        {
            Definition expressionDef;

            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionDef))
            {
                // dont have to print anything
            }

            else
            {
                TypeDefinition typeDef;
                typeDef = (TypeDefinition)expressionDef;

                // add argument to the args list
                args.Add(typeDef);
            }
        }

        public override void OutAMultipleParameters(AMultipleParameters node)
        {
            Definition expressionDef;

            if (!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionDef))
            {
                // dont have to print anything
            }

            else
            {
                TypeDefinition typeDef;
                typeDef = (TypeDefinition)expressionDef;

                // add argument to the args list
                args.Add(typeDef);
            }
        }

    }
}
