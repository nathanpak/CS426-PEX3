﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Xml.Linq;
using CS426.node;

namespace CS426.analysis
{
    class CodeGenerator : DepthFirstAdapter
    {
        StreamWriter _output;

        public CodeGenerator(String outputFilename)
        {
            _output = new StreamWriter(outputFilename);
        }

        private void Write(String textToWrite)
        {
            Console.Write(textToWrite);
            _output.Write(textToWrite);
        }

        private void WriteLine(String textToWrite)
        {
            Console.WriteLine(textToWrite);
            _output.WriteLine(textToWrite);
        }

        public override void InAOnlymainProgram(AOnlymainProgram node)
        {
            WriteLine(".assembly extern mscorlib { }");
            WriteLine(".assembly nathanpak");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAOnlymainProgram(AOnlymainProgram node)
        {
            _output.Close();

            Console.WriteLine("\n\n");
        }


        public override void InAHascontentMainfunc(AHascontentMainfunc node)
        {
            WriteLine(".method static void main() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            WriteLine("\t.entrypoint\n");

        }

        public override void OutAHascontentMainfunc(AHascontentMainfunc node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        public override void OutADeclarationStatement(ADeclarationStatement node)
        {
            WriteLine("\t// Declaring Variable " + node.GetDeclareStatement());

            Write("\t.locals init(");

            if (node.GetType().ToString() == "int")
            {
                Write("int32 ");
            }

            else
            {
                Write(node.GetType().ToString() + " ");
            }

            WriteLine(node.GetType().FullName + ")\n");

        }
    }
}
