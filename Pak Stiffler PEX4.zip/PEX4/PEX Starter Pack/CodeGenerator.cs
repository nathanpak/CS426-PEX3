﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Xml.Linq;
using CS426.node;

namespace CS426.analysis
{
    class CodeGenerator : DepthFirstAdapter
    {
        StreamWriter _output;

        int LABELCOUNTER = 0;

        public CodeGenerator(String outputFilename)
        {
            _output = new StreamWriter(outputFilename);
        }

        private void Write(String textToWrite)
        {
            Console.Write(textToWrite);
            _output.Write(textToWrite);
        }

        private void WriteLine(String textToWrite)
        {
            Console.WriteLine(textToWrite);
            _output.WriteLine(textToWrite);
        }

        /********1.PROGRAM INITIALIZATION*********/
        public override void InAOnlymainProgram(AOnlymainProgram node)
        {
            WriteLine(".assembly extern mscorlib { }");
            WriteLine(".assembly nathanpak");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAOnlymainProgram(AOnlymainProgram node)
        {
            _output.Close();

            Console.WriteLine("\n\n");
        }

        public override void InAConstsProgram(AConstsProgram node)
        {
            WriteLine(".assembly extern mscorlib { }");
            WriteLine(".assembly nathanpak");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAConstsProgram(AConstsProgram node)
        {
            _output.Close();

            Console.WriteLine("\n\n");
        }

        public override void InAFuncsProgram(AFuncsProgram node)
        {
            WriteLine(".assembly extern mscorlib { }");
            WriteLine(".assembly nathanpak");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAFuncsProgram(AFuncsProgram node)
        {
            _output.Close();

            Console.WriteLine("\n\n");
        }

        public override void InAConstsandfuncsProgram(AConstsandfuncsProgram node)
        {
            WriteLine(".assembly extern mscorlib { }");
            WriteLine(".assembly nathanpak");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAConstsandfuncsProgram(AConstsandfuncsProgram node)
        {
            _output.Close();

            Console.WriteLine("\n\n");
        }

        /********2. MAIN FUNCTION*********/
        public override void InAHascontentMainfunc(AHascontentMainfunc node)
        {
            WriteLine(".method static void main() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            WriteLine("\t.entrypoint\n");

        }

        public override void OutAHascontentMainfunc(AHascontentMainfunc node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        public override void InANocontentMainfunc(ANocontentMainfunc node)
        {
            WriteLine(".method static void main() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            WriteLine("\t.entrypoint\n");
        }

        public override void OutANocontentMainfunc(ANocontentMainfunc node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        /********3. USER-DEFINED FUNCTIONS*********/
        public override void InAParametersFunc(AParametersFunc node)
        {
            WriteLine(".method static void " + node.GetId().Text + "() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            //WriteLine("\t" + node.GetStatements());
        }

        public override void OutAParametersFunc(AParametersFunc node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        public override void InANoparametersFunc(ANoparametersFunc node)
        {
            WriteLine(".method static void " + node.GetId().Text + "() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            //WriteLine("\t" + node.GetStatements());
        }

        public override void OutANoparametersFunc(ANoparametersFunc node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        /********4. DECLARING A VARIABLE*********/
        public override void OutARegularDeclareStatement(ARegularDeclareStatement node)
        {
            WriteLine("\t// Declaring Variable " + node.GetVarname());

            Write("\t.locals init(");

            if (node.GetType().Text == "int")
            {
                Write("int32 ");
            }
            else if(node.GetType().Text == "float")
            {
                Write("float32 ");
            }
            else if (node.GetType().Text == "string")
            {
                Write("string ");
            }
            else
            {
                Write(node.GetType().Text + " ");
            }

            WriteLine(node.GetVarname().Text + ")\n");

        }

        /********OPERANDS*********/
        public override void OutAIntOperand(AIntOperand node)
        {
            WriteLine("\tldc.i4 " + node.GetInteger().Text);
        }

        public override void OutAFloatOperand(AFloatOperand node)
        {
            WriteLine("\tldc.r8 " + node.GetFloat().Text);
        }

        public override void OutAStringOperand(AStringOperand node)
        {
            WriteLine("\tldstr " + node.GetString().Text);
        }

        public override void OutAVariableOperand(AVariableOperand node)
        {
            WriteLine("\tldloc " + node.GetId().Text);
        }

        /********5. ASSIGNING A VARIABLE*********/
        public override void OutANormalAssignStatement(ANormalAssignStatement node)
        {
            WriteLine("\tstloc " + node.GetId().Text + "\n");
        }

        /********6-7 CALLING USER-DEFINED FUNCTION*********/
        public override void OutAParamsFunctionCallStatement(AParamsFunctionCallStatement node)
        {
            if (node.GetId().Text == "printInt")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(int32)");
            }
            else if (node.GetId().Text == "printString")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(string)");
            }
            else if (node.GetId().Text == "printFloat")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(float32)");
            }
            else if (node.GetId().Text == "printLine")
            {
                WriteLine("\tldstr \"\\n\"");
                WriteLine("\tcall void [mscorlib]System.Console::Write(string)");
            }
            else
            {
                WriteLine("\tcall void " + node.GetId().Text + "()");
            }
        }

        public override void OutANoparamsFunctionCallStatement(ANoparamsFunctionCallStatement node)
        {
            if (node.GetId().Text == "printLine")
            {
                WriteLine("\tldstr \"\\n\"");
                WriteLine("\tcall void [mscorlib]System.Console::Write(string)");
            }
            else
            {
                WriteLine("\tcall void " + node.GetId().Text + "()");
            }
        }

        /********8-11 ADD, SUB, MULT, DIV*********/
        public override void OutAAddExpression4(AAddExpression4 node)
        {
            WriteLine("\tadd");
        }

        public override void OutASubtractExpression4(ASubtractExpression4 node)
        {
            WriteLine("\tsub");
        }

        public override void OutAMultiplyExpression6(AMultiplyExpression6 node)
        {
            WriteLine("\tmul");
        }

        public override void OutADivisionExpression6(ADivisionExpression6 node)
        {
            WriteLine("\tdiv");
        }

        /********12-15 NEG, NOT, AND, OR*********/
        public override void OutANegativeExpression10(ANegativeExpression10 node)
        {
            WriteLine("\tneg");
        }

        public override void OutANotExpression10(ANotExpression10 node)
        {
            WriteLine("\tldc.i4 0");
            WriteLine("\tceq");
        }

        public override void OutAAndExpression1(AAndExpression1 node)
        {
            WriteLine("\tand");
        }

        public override void OutAOrExpression(AOrExpression node)
        {
            WriteLine("\tor");
        }

        /********16 LOGICAL COMPARISON*********/
        public override void OutAEqualExpression2(AEqualExpression2 node)
        {
            WriteLine("\tbeq label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr label" + (LABELCOUNTER+1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tlabel" + (LABELCOUNTER+1) + ":");
            LABELCOUNTER += 2;
        }

        public override void OutANotequalExpression2(ANotequalExpression2 node)
        {
            WriteLine("\tbeq label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 1");
            WriteLine("\t\tbr label" + (LABELCOUNTER + 1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 0");
            WriteLine("\tlabel" + (LABELCOUNTER + 1) + ":");
            LABELCOUNTER += 2;
        }

        public override void OutALessExpression3(ALessExpression3 node)
        {
            WriteLine("\tblt label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr label" + (LABELCOUNTER + 1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tlabel" + (LABELCOUNTER + 1) + ":");
            LABELCOUNTER += 2;
        }

        public override void OutALessequalExpression3(ALessequalExpression3 node)
        {
            WriteLine("\tble label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr label" + (LABELCOUNTER + 1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tlabel" + (LABELCOUNTER + 1) + ":");
            LABELCOUNTER += 2;
        }

        public override void OutAGreaterExpression3(AGreaterExpression3 node)
        {
            WriteLine("\tbgt label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr label" + (LABELCOUNTER + 1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tlabel" + (LABELCOUNTER + 1) + ":");
            LABELCOUNTER += 2;
        }

        public override void OutAGreaterequalExpression3(AGreaterequalExpression3 node)
        {
            WriteLine("\tbge label" + LABELCOUNTER);
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr label" + (LABELCOUNTER + 1));

            WriteLine("\tlabel" + LABELCOUNTER + ":");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tlabel" + (LABELCOUNTER + 1) + ":");
            LABELCOUNTER += 2;
        }

        /********17 IF/ELSE STATEMENTS*********/
        public override void OutAIfIfStatement(AIfIfStatement node)
        {
            int label1, label2, label3;

            //TEST CODE HERE
            label1 = LABELCOUNTER;
            WriteLine("\tbrtrue label" + label1);
            LABELCOUNTER++;
            label2 = LABELCOUNTER;
            WriteLine("\tbr label" + (label2));

            WriteLine("\tlabel" + label1 + ":");
            LABELCOUNTER++;
            // CODE IF TRUE
            node.GetStatements().Apply(this);
            label3 = LABELCOUNTER;
            WriteLine("\t\tbr label" + label3);
            LABELCOUNTER++;

            WriteLine("\tlabel" + label2 + ":");
            // CODE IF FALSE, AKA NOTHING
            WriteLine("\tlabel" + label3 + ":");
        }

        public override void CaseAIfIfStatement(AIfIfStatement node)
        {
            InAIfIfStatement(node);
            if (node.GetIf() != null)
            {
                node.GetIf().Apply(this);
            }
            if (node.GetOpenparen() != null)
            {
                node.GetOpenparen().Apply(this);
            }
            if (node.GetExpression() != null)
            {
                node.GetExpression().Apply(this);
            }
            if (node.GetCloseparen() != null)
            {
                node.GetCloseparen().Apply(this);
            }
            if (node.GetOpenbracket() != null)
            {
                node.GetOpenbracket().Apply(this);
            }
            
            if (node.GetClosebracket() != null)
            {
                node.GetClosebracket().Apply(this);
            }
            OutAIfIfStatement(node);
        }

        public override void OutAIfelseIfStatement(AIfelseIfStatement node)
        {        
            int label1, label2, label3;

            //TEST CODE HERE
            label1 = LABELCOUNTER;
            WriteLine("\tbrtrue label" + label1);
            LABELCOUNTER++;
            label2 = LABELCOUNTER;
            WriteLine("\tbr label" + (label2));

            WriteLine("\tlabel" + label1 + ":");
            LABELCOUNTER++;
            // CODE IF TRUE
            node.GetIfpathstatements().Apply(this);
            label3 = LABELCOUNTER;
            WriteLine("\t\tbr label" + label3);
            LABELCOUNTER++;

            WriteLine("\tlabel" + label2 + ":");
            // CODE IF FALSE, AKA NOTHING
            node.GetElsepathstatements().Apply(this);
            WriteLine("\tlabel" + label3 + ":");
        }

        public override void CaseAIfelseIfStatement(AIfelseIfStatement node)
        {
            InAIfelseIfStatement(node);
            if (node.GetIf() != null)
            {
                node.GetIf().Apply(this);
            }
            if (node.GetIfpathparenopen() != null)
            {
                node.GetIfpathparenopen().Apply(this);
            }
            if (node.GetExpression() != null)
            {
                node.GetExpression().Apply(this);
            }
            if (node.GetIfpathparenclose() != null)
            {
                node.GetIfpathparenclose().Apply(this);
            }
            if (node.GetIfpathbracketopen() != null)
            {
                node.GetIfpathbracketopen().Apply(this);
            }
            
            if (node.GetIfpathbracketclose() != null)
            {
                node.GetIfpathbracketclose().Apply(this);
            }
            if (node.GetElse() != null)
            {
                node.GetElse().Apply(this);
            }
            if (node.GetElsepathbracketopen() != null)
            {
                node.GetElsepathbracketopen().Apply(this);
            }
            if (node.GetElsepathbracketclose() != null)
            {
                node.GetElsepathbracketclose().Apply(this);
            }
            OutAIfelseIfStatement(node);
        }

        /********18 LOOP*********/
        public override void OutAWhileWhileStatement(AWhileWhileStatement node)
        {
            int label1 = LABELCOUNTER;
            int label2;

            WriteLine("\tlabel" + label1 + ":");
            LABELCOUNTER++;
            // TEST CODE HERE
            node.GetExpression().Apply(this);
            label2 = LABELCOUNTER;
            WriteLine("\tbrzero label" + (label2));
            LABELCOUNTER++;
            // LOOP CODE HERE
            node.GetStatements().Apply(this);
            WriteLine("\tbr label" + label1);
            WriteLine("\tlabel" + label2 + ":");
        }

        public override void CaseAWhileWhileStatement(AWhileWhileStatement node)
        {
            InAWhileWhileStatement(node);
            if (node.GetWhile() != null)
            {
                node.GetWhile().Apply(this);
            }
            if (node.GetOpenparen() != null)
            {
                node.GetOpenparen().Apply(this);
            }

            if (node.GetCloseparen() != null)
            {
                node.GetCloseparen().Apply(this);
            }
            if (node.GetOpenbracket() != null)
            {
                node.GetOpenbracket().Apply(this);
            }
            
            if (node.GetClosebracket() != null)
            {
                node.GetClosebracket().Apply(this);
            }
            OutAWhileWhileStatement(node);
        }
    }
}
