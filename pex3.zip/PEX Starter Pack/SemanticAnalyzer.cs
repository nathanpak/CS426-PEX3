﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CS426.node;

namespace CS426.analysis
{
    class SemanticAnalyzer : DepthFirstAdapter
    {
        // Global symbol table
        Dictionary<string, Definition> globalSymbolTable = new Dictionary<string, Definition>();

        // local symbol table
        Dictionary<string, Definition> localSymbolTable = new Dictionary<string, Definition>();

        // this is our decorated parse tree
        Dictionary<Node, Definition> decoratedParseTree = new Dictionary<Node, Definition>();

        public void PrintWarning(Token t, String message)
        {
            Console.WriteLine("Line " + t.Line + ", Col " + t.Pos + ": " + message);
        }

        public override void InAConstsandfuncsProgram(AConstsandfuncsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAFuncsProgram(AFuncsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAConstsProgram(AConstsProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        public override void InAOnlymainProgram(AOnlymainProgram node)
        {
            // create a definition for integers
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            // create def for floats
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            // create def for strings
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            // register def with the global symbol table
            globalSymbolTable.Add("int", intDefinition);
            globalSymbolTable.Add("float", floatDefinition);
            globalSymbolTable.Add("string", strDefinition);

            Console.WriteLine("You just entered a Program Node");
        }

        /**
         * OPERANDS
         */
        public override void OutAIntOperand(AIntOperand node)
        {
            // create the definition
            Definition intDefinition = new NumberDefinition();
            intDefinition.name = "int";

            decoratedParseTree.Add(node, intDefinition);
        }

        public override void OutAVariableOperand(AVariableOperand node)
        {
            // get name of id
            String varName = node.GetId().Text;

            Definition varDefinition;

            // see if varName is in local symbol table
            if (!localSymbolTable.TryGetValue(varName, out varDefinition))
            {
                PrintWarning(node.GetId(), varName + " does not exist.");
            }
            // see if varDefinition is actually a variable
            else if(!(varDefinition is VariableDefinition))
            {
                PrintWarning(node.GetId(), varName + " is not a variable");
            }
            else
            {
                VariableDefinition v = (VariableDefinition)varDefinition;

                // decorating node with type of the variable
                decoratedParseTree.Add(node, v.variableType);
            }
        }

        public override void OutAFloatOperand(AFloatOperand node)
        {
            Definition floatDefinition = new FloatDefinition();
            floatDefinition.name = "float";

            decoratedParseTree.Add(node, floatDefinition);
        }

        public override void OutAStringOperand(AStringOperand node)
        {
            Definition strDefinition = new StringDefinition();
            strDefinition.name = "string";

            decoratedParseTree.Add(node, strDefinition);
        }

        /**
         * Expression 10
         */
        public override void OutAPassExpression10(APassExpression10 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetOperand(), out operandDefinition)) 
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutANegativeExpression10(ANegativeExpression10 node)
        {
            Definition operandDefinition;

            if (!decoratedParseTree.TryGetValue(node.GetOperand(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else if(!(operandDefinition is NumberDefinition))
            {
                PrintWarning(node.GetSub(), "Only a number can be negated.");
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        public override void OutANotExpression10(ANotExpression10 node)
        {
            Definition operandDefinition;

            if (!decoratedParseTree.TryGetValue(node.GetExpression10(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else if (!(operandDefinition is BooleanDefinition))
            {
                PrintWarning(node.GetNot(), "Not can only be applied to boolean.");
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 9
         */
        public override void OutAPassExpression9(APassExpression9 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression10(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 8
         */
        public override void OutAPassExpression8(APassExpression8 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression9(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 6
         */
        public override void OutAPassExpression6(APassExpression6 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression8(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 4
         */
        public override void OutAPassExpression4(APassExpression4 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression6(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 3
         */
        public override void OutAPassExpression3(APassExpression3 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression4(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 2
         */
        public override void OutAPassExpression2(APassExpression2 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression3(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression 1
         */
        public override void OutAPassExpression1(APassExpression1 node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression2(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Expression
         */
        public override void OutAPassExpression(APassExpression node)
        {
            Definition operandDefinition;
            if (!decoratedParseTree.TryGetValue(node.GetExpression1(), out operandDefinition))
            {
                // the error would have been printed at a lower level in tree
                // so no printing needed
            }
            else
            {
                decoratedParseTree.Add(node, operandDefinition);
            }
        }

        /**
         * Declare Statements
         */
        public override void OutARegularDeclareStatement(ARegularDeclareStatement node)
        {
            Definition typeDef;
            Definition idDef;

            if (!globalSymbolTable.TryGetValue(node.GetType().Text, out typeDef))
            {
                PrintWarning(node.GetType(), "Type " + node.GetType().Text + " does not exist.");
            }
            else if (!(typeDef is TypeDefinition))
            {
                PrintWarning(node.GetType(), "Identifier " + node.GetType().Text + " is not a recognized data type");
            }
            else if (localSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }
            /*else if (globalSymbolTable.TryGetValue(node.GetVarname().Text, out idDef))
            {
                PrintWarning(node.GetVarname(), "Identifier " + node.GetVarname().Text + " is already being used.");
            }*/
            else
            {
                VariableDefinition newVariableDefinition = new VariableDefinition();
                newVariableDefinition.name = node.GetVarname().Text;
                newVariableDefinition.variableType = (TypeDefinition)typeDef;

                localSymbolTable.Add(node.GetVarname().Text, newVariableDefinition);
            }
        }

        public override void OutANormalAssignStatement(ANormalAssignStatement node)
        {
            Definition idDef;
            Definition expressionDef;

            if(!localSymbolTable.TryGetValue(node.GetId().Text, out idDef))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " does not exist.");
            }
            else if(!(idDef is VariableDefinition))
            {
                PrintWarning(node.GetId(), "Identifier " + node.GetId().Text + " is not a variable.");
            }
            else if(!decoratedParseTree.TryGetValue(node.GetExpression(), out expressionDef))
            {
                // no need to print error message
            }
            else if (((VariableDefinition)idDef).variableType.name != expressionDef.name)
            {
                PrintWarning(node.GetId(), "Types do not match");
            }
            else
            {
                // nothing is required! valid assignment.
            }
        }

    }
}
